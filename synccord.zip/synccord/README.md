# SyncCord

Telefon numarası gerektirmeyen, Discord/WhatsApp benzeri gerçek zamanlı sohbet uygulaması.

**Stack:** React + Vite + Tailwind · Node.js + Express · MongoDB · Socket.io

## Kurulum

### 1. Backend
```bash
cd server
npm install
cp .env.example .env   # değerleri doldurun
npm run dev
```

### 2. Frontend
```bash
cd client
npm install
npm run dev
```

Frontend: http://localhost:5173 · Backend: http://localhost:5000

## Yol haritası
- [x] Adım 1: Proje yapısı ve veritabanı şemaları
- [ ] Adım 2: Kayıt / giriş / e-posta OTP doğrulaması
- [ ] Adım 3: Kullanıcı#Kod ile arkadaş ekleme
- [ ] Adım 4: Gerçek zamanlı mesajlaşma arayüzü
