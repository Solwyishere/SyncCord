export default function App() {
  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="rounded-2xl border border-white/10 bg-white/5 backdrop-blur-xl p-10 text-center animate-fadeIn">
        <h1 className="text-3xl font-bold text-brand-light">SyncCord</h1>
        <p className="mt-2 text-slate-400">Kurulum tamam. Adım 2'ye hazırız.</p>
      </div>
    </div>
  );
}
