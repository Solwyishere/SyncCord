import mongoose from "mongoose";

const userSchema = new mongoose.Schema(
  {
    username: { type: String, required: true, trim: true, minlength: 3, maxlength: 20 },
    tag: { type: String, required: true }, // "4582" (4 haneli)
    email: { type: String, required: true, unique: true, lowercase: true },
    password: { type: String, required: true }, // bcrypt hash
    avatar: { type: String, default: "" },

    // E-posta doğrulama (OTP)
    isVerified: { type: Boolean, default: false },
    otpHash: { type: String },
    otpExpires: { type: Date },
    otpAttempts: { type: Number, default: 0 },

    friends: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
    lastSeen: { type: Date, default: Date.now },
  },
  { timestamps: true }
);

// Ahmet#4582 benzersiz olmalı
userSchema.index({ username: 1, tag: 1 }, { unique: true });

export default mongoose.model("User", userSchema);
